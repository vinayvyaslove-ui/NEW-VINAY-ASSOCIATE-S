import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-3xl font-bold mb-4">GST Accounting & Invoicing</h1>
      <p className="mb-4">Starter project — features: invoicing, OCR entry, bank upload, accountant access.</p>
      <div className="space-x-2">
        <Link href="/auth"><a className="px-4 py-2 bg-green-600 text-white rounded">Auth</a></Link>
        <Link href="/invoices"><a className="px-4 py-2 bg-blue-600 text-white rounded">Invoices</a></Link>
        <Link href="/accountant"><a className="px-4 py-2 bg-gray-600 text-white rounded">Accountant</a></Link>
      </div>
    </main>
  )
}
